import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script2 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script3 from "../846479b0-75d3-450d-bbd6-7e6b3355a7a2/src/item"
import Script4 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script5 from "../d5ee9a47-8484-4824-a609-996298830b51/src/item"
import Script6 from "../8bd080c9-9954-43b2-a6ac-0b0913d298c0/src/item"
import Script7 from "../f89ab04f-46ef-42ea-912b-b194eb8d2f02/src/item"
import Script8 from "../b88efbbf-2a9a-47b4-86e1-e38ecc2b433b/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("c9b17021-765c-4d9a-9966-ce93a9c323d1/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(2.57220721244812, 0.8943545818328857, 7.5905537605285645),
  rotation: new Quaternion(5.40884746930495e-16, 0.6954354643821716, -8.290236053198896e-8, 0.718588650226593),
  scale: new Vector3(2.0712456703186035, 2.21431827545166, 1.0000015497207642)
})
nftPictureFrame.addComponentOrReplace(transform3)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(4.816032409667969, 0.8818327188491821, 3.250774383544922),
  rotation: new Quaternion(-6.9643502085875355e-15, -0.0639880895614624, 7.627970255441596e-9, -0.9979507327079773),
  scale: new Vector3(2.183903694152832, 2.25, 1.0388367176055908)
})
nftPictureFrame2.addComponentOrReplace(transform4)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(9.615782737731934, 0.880905270576477, 12.136828422546387),
  rotation: new Quaternion(1.2230335830459155e-14, 0.9999990463256836, -1.1920918296937089e-7, -0.0013874471187591553),
  scale: new Vector3(2.2262189388275146, 2.2336621284484863, 1.0203430652618408)
})
nftPictureFrame3.addComponentOrReplace(transform5)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(10.179224967956543, 3.864919900894165, 7.934325695037842),
  rotation: new Quaternion(-3.5282013923399087e-15, 0.7150779366493225, -8.524392569597694e-8, -0.6990447640419006),
  scale: new Vector3(2.169192314147949, 2.27927827835083, 1.0019750595092773)
})
nftPictureFrame4.addComponentOrReplace(transform6)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(9.736345291137695, 3.888261079788208, 9.884510040283203),
  rotation: new Quaternion(5.184398561359138e-15, 0.7569414973258972, -9.023445812772479e-8, -0.6534826159477234),
  scale: new Vector3(2.1534416675567627, 2.2109148502349854, 1.0456339120864868)
})
nftPictureFrame5.addComponentOrReplace(transform7)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(11.557255744934082, 0.8799115419387817, 8.11880874633789),
  rotation: new Quaternion(0.0008535452070645988, 0.7165165543556213, 0.0008633029065094888, -0.6975690722465515),
  scale: new Vector3(2.1749119758605957, 2.2614047527313232, 1.0053776502609253)
})
nftPictureFrame6.addComponentOrReplace(transform8)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(3.661362648010254, 0.8562619686126709, 5.3579206466674805),
  rotation: new Quaternion(9.081758087936152e-16, 0.49812835454940796, -5.938152014550724e-8, 0.8671033978462219),
  scale: new Vector3(2.1089611053466797, 2.2217354774475098, 1.3681758642196655)
})
nftPictureFrame7.addComponentOrReplace(transform9)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(4.691769599914551, 3.845893383026123, 5.337018966674805),
  rotation: new Quaternion(-1.910459519126025e-15, 0.4923885464668274, -5.8697288807252335e-8, 0.8703755736351013),
  scale: new Vector3(2.162431240081787, 2.229952096939087, 1.3712470531463623)
})
nftPictureFrame8.addComponentOrReplace(transform10)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(11.525227546691895, 0.8885637521743774, 10.596057891845703),
  rotation: new Quaternion(-1.1794461993164512e-14, 0.9206333756446838, -1.0974803643648556e-7, -0.39042818546295166),
  scale: new Vector3(2.1885552406311035, 2.2333950996398926, 1.2151463031768799)
})
nftPictureFrame9.addComponentOrReplace(transform11)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(6.3463521003723145, 3.8890655040740967, 3.9761428833007812),
  rotation: new Quaternion(-5.874392447225438e-15, -0.07275456935167313, 8.673006313131282e-9, -0.9973499178886414),
  scale: new Vector3(2.1103761196136475, 2.1737115383148193, 1.0193713903427124)
})
nftPictureFrame10.addComponentOrReplace(transform12)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(7.827652931213379, 3.8894100189208984, 11.16261100769043),
  rotation: new Quaternion(-1.3927307471493311e-15, 0.9989674687385559, -1.1908618091638346e-7, 0.045430827885866165),
  scale: new Vector3(2.1753287315368652, 2.5703890323638916, 1.008669376373291)
})
nftPictureFrame11.addComponentOrReplace(transform13)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(10.616108894348145, 6.624005317687988, 7.386317729949951),
  rotation: new Quaternion(-1.754313823387494e-14, 0.7528615593910217, -8.974808451966965e-8, -0.6581789255142212),
  scale: new Vector3(2.155825614929199, 2.284050941467285, 1.0226871967315674)
})
nftPictureFrame12.addComponentOrReplace(transform14)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(10.76093578338623, 9.09220027923584, 5.015997886657715),
  rotation: new Quaternion(-3.359972178685732e-15, -0.426507830619812, 5.0843699028746414e-8, 0.9044839143753052),
  scale: new Vector3(2.110576629638672, 2.173403263092041, 1.6724073886871338)
})
nftPictureFrame13.addComponentOrReplace(transform15)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(11.562128067016602, 9.106599807739258, 8.3855619430542),
  rotation: new Quaternion(-6.253835255508105e-15, 0.896128237247467, -1.0682679629780978e-7, -0.44379517436027527),
  scale: new Vector3(2.1011431217193604, 2.1779325008392334, 1.6749091148376465)
})
nftPictureFrame14.addComponentOrReplace(transform16)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(4.924888610839844, 6.639307498931885, 6.535192966461182),
  rotation: new Quaternion(9.096409640341283e-16, 0.6413987278938293, -7.64606795655709e-8, 0.7672078013420105),
  scale: new Vector3(2.1450281143188477, 2.2201952934265137, 1.0429481267929077)
})
nftPictureFrame15.addComponentOrReplace(transform17)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(12.022351264953613, 9.099377632141113, 6.617040634155273),
  rotation: new Quaternion(-5.518875778603863e-15, -0.6558727622032166, 7.81861331233813e-8, 0.7548714876174927),
  scale: new Vector3(2.160245656967163, 2.2206103801727295, 1.0185853242874146)
})
nftPictureFrame16.addComponentOrReplace(transform18)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(5.4427876472473145, 6.6459550857543945, 8.79893684387207),
  rotation: new Quaternion(-6.042428113851167e-16, 0.907421886920929, -1.081731184626733e-7, 0.4202209413051605),
  scale: new Vector3(2.0868921279907227, 2.1939661502838135, 1.8989577293395996)
})
nftPictureFrame17.addComponentOrReplace(transform19)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(7.279062271118164, 6.623350620269775, 10.159712791442871),
  rotation: new Quaternion(-1.544490463935332e-15, 0.987729549407959, -1.17746516536954e-7, 0.15617436170578003),
  scale: new Vector3(2.1650478839874268, 2.2685353755950928, 1.1083859205245972)
})
nftPictureFrame18.addComponentOrReplace(transform20)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(5.788127422332764, 9.082550048828125, 7.811100006103516),
  rotation: new Quaternion(2.268704692628943e-16, 0.7007178068161011, -8.353206482070163e-8, 0.7134385704994202),
  scale: new Vector3(2.1722984313964844, 2.275838613510132, 1.0000011920928955)
})
nftPictureFrame22.addComponentOrReplace(transform21)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(9.5, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform22)

const clickArea = new Entity('clickArea')
engine.addEntity(clickArea)
clickArea.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(7.764484405517578, 3.067854881286621, 7.524996757507324),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6082725524902344, 1.1558641195297241, 1.262404441833496)
})
clickArea.addComponentOrReplace(transform23)

const clickArea2 = new Entity('clickArea2')
engine.addEntity(clickArea2)
clickArea2.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(7.159820079803467, 3.0649912357330322, 7.517360687255859),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6082725524902344, 1.1536401510238647, 1.262404441833496)
})
clickArea2.addComponentOrReplace(transform24)

const clickArea3 = new Entity('clickArea3')
engine.addEntity(clickArea3)
clickArea3.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(7.190782070159912, 6.037832736968994, 7.5331130027771),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6082725524902344, 1.1536401510238647, 1.262404441833496)
})
clickArea3.addComponentOrReplace(transform25)

const clickArea4 = new Entity('clickArea4')
engine.addEntity(clickArea4)
clickArea4.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(7.790363788604736, 6.040746688842773, 7.506966590881348),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6082725524902344, 1.1558641195297241, 1.262404441833496)
})
clickArea4.addComponentOrReplace(transform26)

const clickArea5 = new Entity('clickArea5')
engine.addEntity(clickArea5)
clickArea5.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(7.516254425048828, 8.498917579650879, 7.543601036071777),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4725350141525269, 1.1536401510238647, 1.5463920831680298)
})
clickArea5.addComponentOrReplace(transform27)

const evHaji = new Entity('evHaji')
engine.addEntity(evHaji)
evHaji.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(7.441913604736328, 0.11207497119903564, 7.550681114196777),
  rotation: new Quaternion(-4.460065959811148e-15, -0.7321856021881104, 8.728331124530087e-8, -0.6811051964759827),
  scale: new Vector3(1.0000020265579224, 1, 1.0000020265579224)
})
evHaji.addComponentOrReplace(transform28)
const gltfShape2 = new GLTFShape("62735713-d7ca-4067-bc45-9f05cff2861c/ev_2022_2_01_haji1_2243.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
evHaji.addComponentOrReplace(gltfShape2)

const haji = new Entity('haji')
engine.addEntity(haji)
haji.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(16, 0, 0),
  rotation: new Quaternion(2.7443202570175736e-15, -0.7069416642189026, 8.427399933452762e-8, -0.7072718739509583),
  scale: new Vector3(1.0000001192092896, 1, 1.0000001192092896)
})
haji.addComponentOrReplace(transform29)
const gltfShape3 = new GLTFShape("154e930d-a2b4-4377-9ccb-b1c6465f85a0/2022_02_05_haji_2228.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
haji.addComponentOrReplace(gltfShape3)

const clickArea6 = new Entity('clickArea6')
engine.addEntity(clickArea6)
clickArea6.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(7.437568187713623, 0, 7.533910274505615),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.208816647529602, 1.1558641195297241, 1.262404441833496)
})
clickArea6.addComponentOrReplace(transform30)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(5.353029251098633, 0.5, 6.7706828117370605),
  rotation: new Quaternion(-4.770667435855143e-16, 0.7043431997299194, -8.396424533430036e-8, 0.7098596096038818),
  scale: new Vector3(0.5000005960464478, 0.5, 1.0000011920928955)
})
radio.addComponentOrReplace(transform31)

const instagramButtonLink = new Entity('instagramButtonLink')
engine.addEntity(instagramButtonLink)
instagramButtonLink.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(14, 0, 1.2095251083374023),
  rotation: new Quaternion(2.207734202294394e-15, 1, -1.1920927533992653e-7, 5.960464477539063e-8),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
instagramButtonLink.addComponentOrReplace(transform32)

const discordButtonLink = new Entity('discordButtonLink')
engine.addEntity(discordButtonLink)
discordButtonLink.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(12, 0, 1.1703166961669922),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
discordButtonLink.addComponentOrReplace(transform33)

const twitterButtonLink = new Entity('twitterButtonLink')
engine.addEntity(twitterButtonLink)
twitterButtonLink.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(15, 0, 1.238036870956421),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
twitterButtonLink.addComponentOrReplace(transform34)

const externalLink = new Entity('externalLink')
engine.addEntity(externalLink)
externalLink.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(13.009353637695312, 0.09596437215805054, 1.1817827224731445),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
externalLink.addComponentOrReplace(transform35)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script1.spawn(nftPictureFrame, {"id":"5784800237655953878877368326340059594626","contract":"0xF87E31492Faf9A91B02Ee0dEAAd50d51d56D5d4d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame, channelBus))
script1.spawn(nftPictureFrame2, {"id":"2400","contract":"0x913ae503153d9A335398D0785Ba60A2d63dDB4e2","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame2, channelBus))
script1.spawn(nftPictureFrame3, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint yours now at 0.1eth + gas fees! https://meta-tycoon.club"}, createChannel(channelId, nftPictureFrame3, channelBus))
script1.spawn(nftPictureFrame4, {"id":"1190","contract":"0x79986aF15539de2db9A5086382daEdA917A9CF0C","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame4, channelBus))
script1.spawn(nftPictureFrame5, {"id":"4744","contract":"0xBD4455dA5929D5639EE098ABFaa3241e9ae111Af","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame5, channelBus))
script1.spawn(nftPictureFrame6, {"id":"17354400712967861636632104979020178784336","contract":"0xF87E31492Faf9A91B02Ee0dEAAd50d51d56D5d4d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame6, channelBus))
script1.spawn(nftPictureFrame7, {"id":"115792089237316195423570985008687907848506031528747425550970339503868374679434","contract":"0xF87E31492Faf9A91B02Ee0dEAAd50d51d56D5d4d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame7, channelBus))
script1.spawn(nftPictureFrame8, {"id":"163412","contract":"0x5CC5B05a8A13E3fBDB0BB9FcCd98D38e50F90c38","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame8, channelBus))
script1.spawn(nftPictureFrame9, {"id":"4763953136893138488487244504044754960290","contract":"0xF87E31492Faf9A91B02Ee0dEAAd50d51d56D5d4d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame9, channelBus))
script1.spawn(nftPictureFrame10, {"id":"53240","contract":"0x5CC5B05a8A13E3fBDB0BB9FcCd98D38e50F90c38","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame10, channelBus))
script1.spawn(nftPictureFrame11, {"id":"79340","contract":"0x5CC5B05a8A13E3fBDB0BB9FcCd98D38e50F90c38","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame11, channelBus))
script1.spawn(nftPictureFrame12, {"id":"137781","contract":"0x5CC5B05a8A13E3fBDB0BB9FcCd98D38e50F90c38","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame12, channelBus))
script1.spawn(nftPictureFrame13, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame13, channelBus))
script1.spawn(nftPictureFrame14, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame14, channelBus))
script1.spawn(nftPictureFrame15, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame15, channelBus))
script1.spawn(nftPictureFrame16, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame16, channelBus))
script1.spawn(nftPictureFrame17, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame17, channelBus))
script1.spawn(nftPictureFrame18, {"id":"149209","contract":"0x5CC5B05a8A13E3fBDB0BB9FcCd98D38e50F90c38","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame18, channelBus))
script1.spawn(nftPictureFrame22, {"id":"1","contract":"0x9dC44047750a972dEE1B4b7c9Bb7474fE922992F","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame22, channelBus))
script2.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script3.spawn(clickArea, {"enabled":true,"onClickText":"Up","button":"PRIMARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":3,"z":0,"curve":"linear","speed":3,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea, channelBus))
script3.spawn(clickArea2, {"enabled":true,"onClickText":"Down","button":"SECONDARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":-2.95,"z":0,"curve":"linear","speed":3,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea2, channelBus))
script3.spawn(clickArea3, {"enabled":true,"onClickText":"Down","button":"SECONDARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":-3,"z":0,"curve":"linear","speed":3,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea3, channelBus))
script3.spawn(clickArea4, {"enabled":true,"onClickText":"Up","button":"PRIMARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":2.37,"z":0,"curve":"linear","speed":3,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea4, channelBus))
script3.spawn(clickArea5, {"enabled":true,"onClickText":"Down","button":"SECONDARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":-2.37,"z":0,"curve":"linear","speed":3,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea5, channelBus))
script3.spawn(clickArea6, {"enabled":true,"onClickText":"Up","button":"PRIMARY","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"evHaji","x":0,"y":2.95,"z":0,"curve":"linear","speed":4,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea6, channelBus))
script4.spawn(radio, {"startOn":true,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://mt.mypinata.cloud/ipfs/QmV9VNG9eLATEezya4M1q9LVncVCy6tDocPX1FUGiSsqj8","onActivate":[{"entityName":"toolbox","actionId":"move","values":{"x":0,"y":0,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"move","values":{"x":0,"y":0,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"move","values":{"x":0,"y":0,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, radio, channelBus))
script5.spawn(instagramButtonLink, {"url":"metatycoon.club","bnw":false}, createChannel(channelId, instagramButtonLink, channelBus))
script6.spawn(discordButtonLink, {"url":"metatycoon","bnw":false}, createChannel(channelId, discordButtonLink, channelBus))
script7.spawn(twitterButtonLink, {"url":"metatycoonnft","bnw":false}, createChannel(channelId, twitterButtonLink, channelBus))
script8.spawn(externalLink, {"url":"meta-tycon.club"}, createChannel(channelId, externalLink, channelBus))